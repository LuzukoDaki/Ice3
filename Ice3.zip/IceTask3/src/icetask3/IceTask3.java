/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask3;
import javax.swing.JOptionPane;
/**
 *
 * @author Daki
 */
public class IceTask3 {

    /**
     * @param args the command line arguments
     */
    // linking the login classs to the main method
    Login objLogin = new Login();
    public static void main(String[] args) {
        
      objLogin.checkUserName(){
        
    }
        
        
        
    }
    
}
